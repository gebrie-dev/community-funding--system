from django.contrib import admin
from .models import Campaign, Transaction, WithdrawalRequest

@admin.register(Campaign)
class CampaignAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'status', 'goal', 'total_usd', 'total_birr', 'starting_date', 'ending_date', 'created_by', 'created_at')
    list_filter = ('category', 'status', 'starting_date', 'ending_date', 'created_by')
    search_fields = ('title', 'description', 'location', 'created_by__email')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at', 'total_usd', 'total_birr')
    fieldsets = (
        (None, {
            'fields': ('title', 'category', 'description', 'goal', 'status')
        }),
        ('Details', {
            'fields': ('total_usd', 'total_birr', 'starting_date', 'ending_date', 'location', 'created_by')
        }),
        ('Media', {
            'fields': ('image', 'document')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('created_by')

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('transaction_id', 'campaign', 'amount', 'payment_method', 'donor_email', 'donor_phone', 'completed', 'created_at')
    list_filter = ('payment_method', 'completed', 'created_at', 'campaign')
    search_fields = ('transaction_id', 'donor_email', 'donor_phone', 'campaign__title')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)
    fieldsets = (
        (None, {
            'fields': ('campaign', 'amount', 'payment_method', 'transaction_id', 'completed')
        }),
        ('Donor Info', {
            'fields': ('donor_email', 'donor_phone')
        }),
        ('Timestamp', {
            'fields': ('created_at',)
        }),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('campaign')

@admin.register(WithdrawalRequest)
class WithdrawalRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'campaign', 'requested_amount', 'payment_method', 'convert_to', 'status', 'created_at')
    list_filter = ('payment_method', 'status', 'convert_to', 'created_at', 'campaign')
    search_fields = ('campaign__title', 'recipient_email', 'recipient_phone')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        (None, {
            'fields': ('campaign', 'requested_amount', 'payment_method', 'convert_to', 'status')
        }),
        ('Recipient Info', {
            'fields': ('recipient_email', 'recipient_phone')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('campaign')