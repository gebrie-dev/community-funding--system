from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.utils.decorators import method_decorator
from django.conf import settings
from django.contrib.auth.decorators import login_required
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from .models import Transaction, WithdrawalRequest
from campaigns.models import Campaign
from .serializers import CampaignSerializer
import requests
import time
import uuid
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)

def validate_amount(amount):
    """Validate that the amount is a positive number."""
    try:
        amount = float(amount)
        if amount <= 0:
            raise ValueError
        return Decimal(str(amount)).quantize(Decimal('0.01')), None
    except (ValueError, TypeError):
        return None, "Amount must be a positive number greater than 0."

import uuid
import re

def initiate_chapa_payment(amount, campaign_id, donor_email, donor_phone):
    """Initiate a Chapa payment with donor details."""
    amount_val, amount_error = validate_amount(amount)
    if amount_error:
        logger.error(f"Chapa validation error: {amount_error}")
        return {'success': False, 'error': amount_error}

    if not settings.SITE_URL.startswith('https://'):
        logger.error(f"Invalid SITE_URL: {settings.SITE_URL}. Must use HTTPS.")
        return {'success': False, 'error': 'Server configuration error: SITE_URL must use HTTPS.'}

    # Validate phone number format: +251 followed by 9 or 10 digits
    phone_pattern = r'^\+251[79]\d{8,9}$'
    if not donor_phone or not re.match(phone_pattern, donor_phone):
        logger.error(f"Invalid donor phone format: {donor_phone}")
        return {
            'success': False,
            'error': 'Phone number must be in +251XXXXXXXXX or +251XXXXXXXXXX format (9 or 10 digits after +251, starting with 7 or 9).'
        }

    url = "https://api.chapa.co/v1/transaction/initialize"
    headers = {
        "Authorization": f"Bearer {settings.CHAPA_TEST_SECRET_KEY}",
        "Content-Type": "application/json"
    }
    tx_ref = f"CHAPA-{int(time.time())}-{campaign_id}-{uuid.uuid4().hex[:8]}"
    payload = {
        "amount": float(amount_val),
        "currency": "ETB",
        "email": donor_email or "donor@chapa.co",
        "phone_number": donor_phone,
        "first_name": "Donor",
        "last_name": "User",
        "tx_ref": tx_ref,
        "callback_url": f"{settings.SITE_URL}/api/callback/chapa/",
        "return_url": f"{settings.SITE_URL}/api/callback/chapa/?campaign_id={campaign_id}&tx_ref={tx_ref}"
    }
    try:
        logger.debug(f"Sending Chapa request with payload: {payload}")
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        logger.debug(f"Chapa API response: {data}")
        if data.get('status') == 'success' and data.get('data', {}).get('checkout_url'):
            return {
                'success': True,
                'checkout_url': data['data']['checkout_url'],
                'transaction_id': data['data'].get('tx_ref', tx_ref)
            }
        logger.error(f"Chapa API returned failure: {data.get('message', 'Unknown error')}")
        return {'success': False, 'error': data.get('message', 'Payment initialization failed')}
    except requests.HTTPError as e:
        try:
            error_response = e.response.json()
            logger.error(f"Chapa API error response: {error_response}")
            error_message = error_response.get('message', str(e))
        except ValueError:
            error_message = str(e)
            logger.error(f"Chapa API error (no JSON response): {error_message}")
        return {'success': False, 'error': f'Failed to connect to Chapa: {error_message}'}
    except requests.RequestException as e:
        logger.error(f"Chapa payment initialization failed: {str(e)}")
        return {'success': False, 'error': f'Failed to connect to Chapa: {str(e)}'}

def verify_chapa_payment(transaction_id):
    """Verify a Chapa payment."""
    url = f"https://api.chapa.co/v1/transaction/verify/{transaction_id}"
    headers = {
        "Authorization": f"Bearer {settings.CHAPA_TEST_SECRET_KEY}",
        "Content-Type": "application/json"
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        logger.debug(f"Chapa verification response: {data}")
        
        # Check if API call was successful and payment is confirmed
        if data.get('status') == 'success' and isinstance(data.get('data'), dict):
            payment_status = data['data'].get('status')
            if payment_status == 'success':
                amount = Decimal(data['data'].get('amount', '0.00'))
                return {'success': True, 'amount': amount, 'message': 'Payment verified successfully'}
            else:
                logger.error(f"Chapa payment not successful: status={payment_status}, message={data.get('message', 'No message provided')}")
                return {
                    'success': False,
                    'message': f'Payment not completed: status is {payment_status}',
                    'data': data.get('data')
                }
        else:
            logger.error(f"Invalid Chapa response: status={data.get('status')}, message={data.get('message', 'No message provided')}")
            return {
                'success': False,
                'message': f'Invalid response from Chapa: {data.get("message", "Unknown error")}'
            }
    except requests.HTTPError as e:
        try:
            error_response = e.response.json()
            logger.error(f"Chapa API error response: {error_response}")
            error_message = error_response.get('message', str(e))
        except ValueError:
            error_message = str(e)
            logger.error(f"Chapa API error (no JSON response): {error_message}")
        return {'success': False, 'message': f'Failed to verify payment: {error_message}'}
    except requests.RequestException as e:
        logger.error(f"Chapa payment verification failed: {str(e)}")
        return {'success': False, 'message': f'Failed to verify payment: {str(e)}'}

def initiate_paypal_payment(campaign, amount, donor_email):
    """Initiate a PayPal payment."""
    logger.debug(f"Initiating PayPal payment for campaign {campaign.id}, amount {amount}")
    auth_url = "https://api-m.sandbox.paypal.com/v1/oauth2/token"
    auth_headers = {"Accept": "application/json", "Accept-Language": "en_US"}
    auth_data = {"grant_type": "client_credentials"}
    try:
        auth_response = requests.post(
            auth_url,
            auth=(settings.PAYPAL_CLIENT_ID, settings.PAYPAL_CLIENT_SECRET),
            headers=auth_headers,
            data=auth_data,
            timeout=10
        )
        auth_response.raise_for_status()
        token = auth_response.json().get("access_token")
        if not token:
            logger.error("No PayPal access token received")
            return {'success': False, 'error': "Failed to authenticate with PayPal"}
    except requests.RequestException as e:
        logger.error(f"PayPal auth failed: {str(e)}")
        return {'success': False, 'error': f"PayPal auth failed: {str(e)}"}

    order_url = "https://api-m.sandbox.paypal.com/v2/checkout/orders"
    headers = {'Content-Type': 'application/json', 'Authorization': f'Bearer {token}'}
    payload = {
        'intent': 'CAPTURE',
        'purchase_units': [{
            'amount': {'currency_code': 'USD', 'value': f"{amount:.2f}"},
            'custom_id': donor_email
        }],
        'application_context': {
            'return_url': f'{settings.SITE_URL}/api/callback/paypal/',
            'cancel_url': f'{settings.SITE_URL}/api/cancel/'
        }
    }
    try:
        response = requests.post(order_url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        redirect_url = next(link['href'] for link in data['links'] if link['rel'] == 'approve')
        return {
            'success': True,
            'checkout_url': redirect_url,
            'transaction_id': data['id']
        }
    except requests.RequestException as e:
        logger.error(f"PayPal order creation failed: {str(e)}")
        return {'success': False, 'error': f"PayPal order creation failed: {str(e)}"}

def simulate_paypal_transfer(amount, recipient_email):
    """Simulate a PayPal transfer."""
    logger.debug(f"Simulated PayPal transfer: {amount} USD to {recipient_email}")
    return {'success': True, 'message': f"Transferred {amount} USD to {recipient_email}"}

def test_page(request):
    """Render the test page with campaign data."""
    campaigns = Campaign.objects.all()
    context = {
        'campaigns': campaigns,
        'campaign_message': request.session.pop('campaign_message', None),
        'campaign_error': request.session.pop('campaign_error', None),
        'chapa_message': request.session.pop('chapa_message', None),
        'chapa_error': request.session.pop('chapa_error', None),
        'paypal_message': request.session.pop('paypal_message', None),
        'paypal_error': request.session.pop('paypal_error', None),
        'withdrawal_message': request.session.pop('withdrawal_message', None),
        'withdrawal_error': request.session.pop('withdrawal_error', None),
    }
    return render(request, 'payments/test.html', context)

class CreateCampaignView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create a new campaign."""
        logger.debug(f"CreateCampaignView.post called with data: {request.data}")
        serializer = CampaignSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": f"Campaign '{serializer.data['title']}' created successfully!", "data": serializer.data},
                status=status.HTTP_201_CREATED
            )
        logger.error(f"Campaign creation failed: {serializer.errors}")
        return Response({"error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

class CampaignListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        """List all approved campaigns."""
        campaigns = Campaign.objects.filter(status='APPROVED')
        serializer = CampaignSerializer(campaigns, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class CampaignDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk):
        """Get details of a specific campaign."""
        try:
            campaign = Campaign.objects.get(pk=pk, status='APPROVED')
            serializer = CampaignSerializer(campaign)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Campaign.DoesNotExist:
            logger.error(f"Campaign {pk} not found or not approved")
            return Response({"error": "Campaign not found or not approved"}, status=status.HTTP_404_NOT_FOUND)

from django.db import transaction, DatabaseError, IntegrityError

class DonateView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        """Handle donation requests."""
        logger.debug(f"DonateView.post called with data: {request.data}")
        data = request.data
        campaign_id = data.get('campaign_id', '').strip()
        amount = data.get('amount', '').strip()
        payment_method = data.get('payment_method', '').strip()
        donor_email = data.get('donor_email', '').strip()
        donor_phone = data.get('donor_phone', '').strip()

        # Validate required fields
        if not all([campaign_id, amount, payment_method]):
            logger.error("Missing required fields: campaign_id, amount, or payment_method")
            return Response(
                {"error": "Please provide campaign ID, amount, and payment method."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate amount
        amount_val, amount_error = validate_amount(amount)
        if amount_error:
            logger.error(f"Invalid amount: {amount_error}")
            return Response({"error": amount_error}, status=status.HTTP_400_BAD_REQUEST)

        # Validate campaign
        try:
            campaign = Campaign.objects.get(id=int(campaign_id), status='APPROVED')
        except (Campaign.DoesNotExist, ValueError):
            logger.error(f"Campaign {campaign_id} not found or not approved")
            return Response(
                {"error": "Campaign not found or not approved."},
                status=status.HTTP_404_NOT_FOUND
            )

        # Validate payment method
        if payment_method not in ['paypal', 'chapa']:
            logger.error(f"Invalid payment method: {payment_method}")
            return Response(
                {"error": "Please choose either PayPal or Chapa."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate donor details
        if payment_method == 'paypal' and not donor_email:
            logger.error("Missing donor email for PayPal")
            return Response(
                {"error": "Please provide a donor email for PayPal."},
                status=status.HTTP_400_BAD_REQUEST
            )
        if payment_method == 'chapa' and not donor_phone:
            logger.error("Missing donor phone for Chapa")
            return Response(
                {"error": "Please provide a donor phone number for Chapa."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Initiate payment
        try:
            if payment_method == 'chapa':
                result = initiate_chapa_payment(amount_val, campaign_id, donor_email, donor_phone)
                if not result['success']:
                    logger.error(f"Chapa payment initiation failed: {result['error']}")
                    return Response(
                        {"error": result['error']},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            else:  # PayPal
                result = initiate_paypal_payment(campaign, amount_val, donor_email)
                if not result['success']:
                    logger.error(f"PayPal payment initiation failed: {result['error']}")
                    return Response(
                        {"error": result['error']},
                        status=status.HTTP_400_BAD_REQUEST
                    )
        except Exception as e:
            logger.error(f"Payment initiation failed: {str(e)}")
            return Response(
                {"error": f"Failed to initiate payment: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        # Create transaction
        try:
            with transaction.atomic():
                new_transaction = Transaction.objects.create(
                    campaign=campaign,
                    amount=amount_val,
                    payment_method=payment_method,
                    transaction_id=result['transaction_id'],
                    donor_email=donor_email or None,
                    donor_phone=donor_phone or None
                )
                logger.info(f"Created {payment_method} transaction: {new_transaction.transaction_id} for campaign {campaign_id}")
        except IntegrityError as e:
            logger.error(f"Database integrity error creating transaction for campaign {campaign_id}: {str(e)}")
            return Response(
                {"error": f"Failed to create transaction due to database constraint: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        except DatabaseError as e:
            logger.error(f"Database error creating transaction for campaign {campaign_id}: {str(e)}")
            return Response(
                {"error": f"Database error creating transaction: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        except Exception as e:
            logger.error(f"Unexpected error creating transaction for campaign {campaign_id}: {str(e)}")
            return Response(
                {"error": f"Error creating transaction: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        # Return success response
        return Response(
            {
                "message": f"{payment_method.capitalize()} payment initiated",
                "checkout_url": result['checkout_url'],
                "transaction_id": result['transaction_id']
            },
            status=status.HTTP_200_OK
        )

class ChapaCallbackView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        """Handle Chapa payment callback (POST from Chapa)."""
        logger.debug(f"ChapaCallbackView.post called with data: {request.data}")
        transaction_id = request.data.get('tx_ref')
        if not transaction_id:
            logger.error("No transaction ID provided in Chapa callback")
            return Response({"error": "Missing transaction ID"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            transaction = Transaction.objects.get(transaction_id=transaction_id)
        except Transaction.DoesNotExist:
            logger.error(f"Transaction {transaction_id} not found")
            return Response({"error": "Transaction not found"}, status=status.HTTP_404_NOT_FOUND)

        if transaction.completed:
            logger.debug(f"Transaction {transaction_id} already completed")
            return Response({"message": "Payment already processed"}, status=status.HTTP_200_OK)

        result = verify_chapa_payment(transaction_id)
        if result['success']:
            try:
                with transaction.atomic():
                    transaction.completed = True
                    transaction.campaign.total_birr += result['amount']
                    transaction.campaign.save()
                    transaction.save()
                logger.info(f"Chapa payment {transaction_id} completed, updated campaign {transaction.campaign.id} balance: {transaction.campaign.total_birr} ETB")
                return Response(
                    {"message": f"Successful donation of {result['amount']} ETB via Chapa"},
                    status=status.HTTP_200_OK
                )
            except Exception as e:
                logger.error(f"Failed to update transaction {transaction_id}: {str(e)}")
                return Response(
                    {"error": f"Failed to process payment: {str(e)}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        logger.error(f"Chapa verification failed: {result['message']}")
        return Response(
            {
                "error": f"Payment verification failed: {result['message']}",
                "details": result.get('data', {})
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    def get(self, request):
        """Handle redirect back from Chapa (GET after user approval)."""
        logger.debug(f"Chapa callback GET request data: {request.GET}")
        transaction_id = request.GET.get('tx_ref')
        if not transaction_id:
            logger.error("No transaction ID provided in Chapa callback GET")
            return Response({"error": "Missing transaction ID"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            transaction = Transaction.objects.get(transaction_id=transaction_id)
        except Transaction.DoesNotExist:
            logger.error(f"Transaction {transaction_id} not found")
            return Response({"error": "Transaction not found"}, status=status.HTTP_404_NOT_FOUND)

        if transaction.completed:
            logger.debug(f"Transaction {transaction_id} already completed")
            return Response({"message": "Payment already processed"}, status=status.HTTP_200_OK)

        result = verify_chapa_payment(transaction_id)
        if result['success']:
            try:
                with transaction.atomic():
                    transaction.completed = True
                    transaction.campaign.total_birr += result['amount']
                    transaction.campaign.save()
                    transaction.save()
                logger.info(f"Chapa payment {transaction_id} completed, updated campaign {transaction.campaign.id} balance: {transaction.campaign.total_birr} ETB")
                return Response(
                    {"message": f"Successful donation of {result['amount']} ETB via Chapa"},
                    status=status.HTTP_200_OK
                )
            except Exception as e:
                logger.error(f"Failed to update transaction {transaction_id}: {str(e)}")
                return Response(
                    {"error": f"Failed to process payment: {str(e)}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        logger.error(f"Chapa verification failed in GET: {result['message']}")
        return Response(
            {
                "error": f"Payment verification failed: {result['message']}",
                "details": result.get('data', {})
            },
            status=status.HTTP_400_BAD_REQUEST
        )

class PayPalCallbackView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        """Handle PayPal payment callback (IPN or webhook)."""
        logger.debug(f"PayPalCallbackView.post called with data: {request.data}")
        transaction_id = request.data.get('transaction_id') or request.data.get('id')
        if not transaction_id:
            logger.error("No transaction ID provided in PayPal callback")
            return Response({"error": "Missing transaction ID"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            transaction = Transaction.objects.get(transaction_id=transaction_id)
        except Transaction.DoesNotExist:
            logger.error(f"Transaction {transaction_id} not found")
            return Response({"error": "Transaction not found"}, status=status.HTTP_404_NOT_FOUND)

        if transaction.completed:
            logger.debug(f"Transaction {transaction_id} already completed")
            return Response({"message": "Payment already processed"}, status=status.HTTP_200_OK)

        return self.verify_paypal_payment(transaction)

    def get(self, request):
        """Handle PayPal payment redirect after approval."""
        logger.debug(f"PayPal callback GET request data: {request.GET}")
        token = request.GET.get('token')
        if not token:
            logger.error("No token provided in PayPal callback")
            return Response({"error": "Missing token"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            transaction = Transaction.objects.get(transaction_id=token)
        except Transaction.DoesNotExist:
            logger.error(f"Transaction {token} not found")
            return Response({"error": "Transaction not found"}, status=status.HTTP_404_NOT_FOUND)

        if transaction.completed:
            logger.debug(f"Transaction {token} already completed")
            return Response({"message": "Payment already processed"}, status=status.HTTP_200_OK)

        return self.verify_paypal_payment(transaction)

    def verify_paypal_payment(self, transaction):
        """Verify a PayPal payment."""
        logger.debug(f"Verifying PayPal payment for transaction {transaction.transaction_id}")
        auth_url = "https://api-m.sandbox.paypal.com/v1/oauth2/token"
        auth_headers = {"Accept": "application/json", "Accept-Language": "en_US"}
        auth_data = {"grant_type": "client_credentials"}
        try:
            auth_response = requests.post(
                auth_url,
                auth=(settings.PAYPAL_CLIENT_ID, settings.PAYPAL_CLIENT_SECRET),
                headers=auth_headers,
                data=auth_data,
                timeout=10
            )
            auth_response.raise_for_status()
            token = auth_response.json().get("access_token")
            if not token:
                logger.error("No PayPal access token received")
                return Response({"error": "No PayPal access token received"}, status=status.HTTP_400_BAD_REQUEST)
        except requests.RequestException as e:
            logger.error(f"PayPal auth failed: {str(e)}")
            return Response({"error": f"PayPal auth failed: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        url = f"https://api-m.sandbox.paypal.com/v2/checkout/orders/{transaction.transaction_id}/capture"
        headers = {'Content-Type': 'application/json', 'Authorization': f'Bearer {token}'}
        try:
            response = requests.post(url, headers=headers, timeout=10)
            response.raise_for_status()
            data = response.json()
            with transaction.atomic():
                transaction.completed = True
                transaction.campaign.total_usd += transaction.amount
                transaction.campaign.save()
                transaction.save()
            logger.info(f"PayPal payment {transaction.transaction_id} completed, updated campaign {transaction.campaign.id} balance: {transaction.campaign.total_usd} USD")
            return Response(
                {"message": f"Successful donation via PayPal! Amount: ${transaction.amount:.2f}"},
                status=status.HTTP_200_OK
            )
        except requests.HTTPError as e:
            logger.error(f"PayPal capture failed: {str(e)}")
            return Response({"error": f"PayPal capture failed: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

@method_decorator(login_required, name='dispatch')
class WithdrawView(APIView):
    permission_classes = [IsAuthenticated]

    def get_exchange_rate(self, from_currency, to_currency):
        """Fetch exchange rate with retries."""
        from payments.utils.exchange_rate import get_exchange_rate
        api_key = getattr(settings, 'EXCHANGE_RATE_API_KEY', None)
        return get_exchange_rate(from_currency, to_currency, api_key=api_key)

    def post(self, request):
        """Handle withdrawal requests."""
        logger.debug(f"WithdrawView.post called with data: {request.data}")
        data = request.data
        campaign_id = data.get('campaign_id', '').strip()
        payment_method = data.get('payment_method', '').strip()
        recipient_email = data.get('recipient_email', '').strip()
        recipient_phone = data.get('recipient_phone', '').strip()
        amount = data.get('amount', '').strip()
        convert_to = data.get('convert_to', 'birr').strip().lower()

        try:
            campaign = Campaign.objects.get(id=int(campaign_id))
            if campaign.created_by != request.user:
                logger.error(f"User {request.user} is not the creator of campaign {campaign_id}")
                return Response(
                    {"error": "You can only withdraw from campaigns you created."},
                    status=status.HTTP_403_FORBIDDEN
                )
        except (ValueError, Campaign.DoesNotExist):
            logger.error(f"Campaign {campaign_id} not found or invalid ID")
            return Response(
                {"error": "Campaign not found or invalid ID."},
                status=status.HTTP_404_NOT_FOUND
            )

        if payment_method not in ['paypal', 'chapa']:
            logger.error(f"Invalid payment method: {payment_method}")
            return Response(
                {"error": "Please choose either PayPal or Chapa."},
                status=status.HTTP_400_BAD_REQUEST
            )
        if payment_method == 'paypal' and not recipient_email:
            logger.error("Missing recipient email for PayPal")
            return Response(
                {"error": "Please provide a recipient email for PayPal."},
                status=status.HTTP_400_BAD_REQUEST
            )
        if payment_method == 'chapa' and not recipient_phone:
            logger.error("Missing recipient phone for Chapa")
            return Response(
                {"error": "Please provide a recipient phone number for Chapa."},
                status=status.HTTP_400_BAD_REQUEST
            )

        amount_val, amount_error = validate_amount(amount)
        if amount_error:
            logger.error(f"Invalid amount: {amount_error}")
            return Response({"error": amount_error}, status=status.HTTP_400_BAD_REQUEST)

        rate = self.get_exchange_rate('USD', 'ETB')
        if rate == 0:
            rate = 132.1
            logger.warning(f"Using fallback exchange rate USD to ETB: {rate}")

        amount_in_birr = amount_val if convert_to == 'birr' else amount_val * Decimal(str(rate))
        total_available = campaign.total_birr + (campaign.total_usd * Decimal(str(rate)))

        if total_available < amount_in_birr:
            logger.error(f"Insufficient funds: requested {amount_in_birr} ETB, available {total_available} ETB")
            return Response(
                {"error": f"Not enough funds! Requested {amount_in_birr:.2f} ETB, available {total_available:.2f} ETB."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            with transaction.atomic():
                withdrawal = WithdrawalRequest.objects.create(
                    campaign=campaign,
                    requested_amount=amount_val,
                    payment_method=payment_method,
                    recipient_email=recipient_email if payment_method == 'paypal' else None,
                    recipient_phone=recipient_phone if payment_method == 'chapa' else None,
                    convert_to=convert_to
                )
            logger.info(f"Withdrawal request created: ID {withdrawal.id}, {amount_val} {convert_to.upper()}")
            return Response(
                {"message": f"Withdrawal request (ID: {withdrawal.id}) is pending admin approval."},
                status=status.HTTP_201_CREATED
            )
        except Exception as e:
            logger.error(f"Failed to create withdrawal request: {str(e)}")
            return Response(
    {
        "success": False,
        "error": f"Error creating withdrawal request: {str(e)}"
    },
    status=status.HTTP_500_INTERNAL_SERVER_ERROR
)
