from django.urls import path
from . import views


urlpatterns = [
    path('campaigns/create/', views.CreateCampaignView.as_view(), name='create-campaign'),
    path('campaigns/', views.CampaignListView.as_view(), name='list-campaigns'),
    path('campaigns/<int:pk>/', views.CampaignDetailView.as_view(), name='campaign-detail'),
    path('donate/', views.DonateView.as_view(), name='donate'),
    path('callback/chapa/', views.ChapaCallbackView.as_view(), name='chapa-callback'),
    path('callback/paypal/', views.PayPalCallbackView.as_view(), name='paypal-callback'),
    path('withdraw/', views.WithdrawView.as_view(), name='withdraw'),

]
