from rest_framework import serializers
from campaigns.models import Campaign
from django.contrib.auth import get_user_model

User = get_user_model()

class CampaignSerializer(serializers.ModelSerializer):
    created_by = serializers.PrimaryKeyRelatedField(read_only=True, default=serializers.CurrentUserDefault())
    image = serializers.ImageField(required=False, allow_null=True)
    document = serializers.FileField(required=False, allow_null=True)
    percentage_funded = serializers.SerializerMethodField()
    balance_in_birr = serializers.SerializerMethodField()

    class Meta:
        model = Campaign
        fields = [
            'id', 'title', 'description', 'goal', 'total_usd', 'total_birr',
            'category', 'location', 'starting_date', 'ending_date', 'image',
            'document', 'status', 'created_by', 'created_at', 'updated_at',
            'percentage_funded', 'balance_in_birr'
        ]
        read_only_fields = ['id', 'total_usd', 'total_birr', 'status', 'created_by', 'created_at', 'updated_at']

    def get_percentage_funded(self, obj):
        return obj.get_percentage_funded()

    def get_balance_in_birr(self, obj):
        return obj.get_balance_in_birr()

    def validate(self, data):
        if 'starting_date' in data and data['starting_date']:
            from datetime import date
            if data['starting_date'] < date.today():
                raise serializers.ValidationError({"starting_date": "Starting date cannot be in the past."})
        if 'starting_date' in data and 'ending_date' in data:
            if data.get('ending_date') and data['starting_date'] and data['ending_date'] <= data['starting_date']:
                raise serializers.ValidationError({"ending_date": "Ending date must be after starting date."})
        return data

    def create(self, validated_data):
        validated_data['created_by'] = self.context['request'].user
        return super().create(validated_data)